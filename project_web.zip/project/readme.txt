In order for the pages to work, please extract from the zip files
the main page is start.html (this is the intended start for the user experience)